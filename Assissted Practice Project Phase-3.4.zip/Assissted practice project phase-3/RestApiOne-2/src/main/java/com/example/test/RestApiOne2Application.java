package com.example.test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestApiOne2Application {

	public static void main(String[] args) {
		SpringApplication.run(RestApiOne2Application.class, args);
	}

}
