package phase1;

public class Calling_Method {

	public static void main(String[] args) {
	
		        // Call the printMessage method with one argument
		        printMessage("Hello, World!");

		        // Call the addNumbers method with two arguments and print the result
		        int sum = addNumbers(10, 20);
		        System.out.println("The sum of 10 and 20 is " + sum);

		        // Call the multiplyNumbers method with three arguments and print the result
		        int product = multiplyNumbers(2, 3, 4);
		        System.out.println("The product of 2, 3, and 4 is " + product);

		        // Call the printName method with no arguments
		        printName();

		        // Call the getGreeting method with one argument and print the result
		        String greeting = getGreeting("John");
		        System.out.println(greeting);
		    }

		    // Method that takes one String argument and prints it to the console
		    public static void printMessage(String message) {
		        System.out.println(message);
		    }

		    // Method that takes two int arguments and returns their sum
		    public static int addNumbers(int a, int b) {
		        return a + b;
		    }

		    // Method that takes three int arguments and returns their product
		    public static int multiplyNumbers(int a, int b, int c) {
		        return a * b * c;
		    }

		    // Method that takes no arguments and prints a name to the console
		    public static void printName() {
		        System.out.println("My name is Java.");
		    }

		    // Method that takes one String argument and returns a greeting
		    public static String getGreeting(String name) {
		        return "Hello, " + name + "!";
		    }
		

	

}
