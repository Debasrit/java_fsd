package phase1;

public class Constructor_type {

		    private String name;
		    private int age;

		    // Default constructor
		    public Constructor_type() {
		        name = "Debas";
		        age = 0;
		    }

		    // Constructor with two parameters
		    public Constructor_type(String name, int age) {
		        this.name = name;
		        this.age = age;
		    }

		    // Copy constructor
		    public Constructor_type(Constructor_type obj) {
		        this.name = obj.name;
		        this.age = obj.age;
		    }

		    public String getName() {
		        return name;
		    }

		    public int getAge() {
		        return age;
		    }

		    public static void main(String[] args) {
		        // Create an object using the default constructor
		    	Constructor_type person1 = new Constructor_type();

		        // Create an object using the constructor with two parameters
		    	Constructor_type person2 = new Constructor_type("Debas", 30);

		        // Create an object using the copy constructor
		    	Constructor_type person3 = new Constructor_type(person2);

		        // Print out the details of each person object
		        System.out.println("Person 1: " + person1.getName() + " (" + person1.getAge() + ")");
		        System.out.println("Person 2: " + person2.getName() + " (" + person2.getAge() + ")");
		        System.out.println("Person 3: " + person3.getName() + " (" + person3.getAge() + ")");
		    }
		

	

}
