package phase1;

public class ImplementAccessModifiers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		        MyClass myClass = new MyClass();

		        // Accessing public method
		        myClass.publicMethod();

		        // Accessing protected method
		        myClass.protectedMethod();

		        // Accessing default method
		        myClass.defaultMethod();

		        // The following line will generate an error, as privateMethod() is not accessible outside the MyClass class
		        // myClass.privateMethod();
		    }
		}

		class MyClass {
		    public void publicMethod() {
		        System.out.println("This is a public method.");
		    }

		    protected void protectedMethod() {
		        System.out.println("This is a protected method.");
		    }

		    void defaultMethod() {
		        System.out.println("This is a default method.");
		    }

		    private void privateMethod() {
		        System.out.println("This is a private method.");
		    
		

	}

}
