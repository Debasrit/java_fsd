package phase1;

public class ImplementationArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		        // Declare and initialize an array of integers
		        int[] intArray = { 1, 2, 3, 4, 5, 6 };

		        // Print the values of the array
		        System.out.print("intArray: ");
		        for (int i = 0; i < intArray.length; i++) {
		            System.out.print(intArray[i] + " ");
		        }
		        System.out.println();

		        // Declare and initialize an array of strings
		        String[] stringArray = { "Hello", "Debasrit", "!" };

		        // Print the values of the array
		        System.out.print("stringArray: ");
		        for (int i = 0; i < stringArray.length; i++) {
		            System.out.print(stringArray[i] + " ");
		        }
		        System.out.println();

		        // Declare an array of doubles and initialize with zeros
		        double[] doubleArray = new double[5];

		        // Print the values of the array
		        System.out.print("doubleArray: ");
		        for (int i = 0; i < doubleArray.length; i++) {
		            System.out.print(doubleArray[i] + " ");
		        }
		        System.out.println();

		        // Update the values of the array
		        doubleArray[0] = 1.1;
		        doubleArray[1] = 2.2;
		        doubleArray[2] = 3.3;

		        // Print the updated values of the array
		        System.out.print("doubleArray: ");
		        for (int i = 0; i < doubleArray.length; i++) {
		            System.out.print(doubleArray[i] + " ");
		        }
		        System.out.println();
		    
		

	}

}
