package phase1;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ImplementationsRegularExpressions {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		        // Create a pattern to match a string with three digits followed by a hyphen and four digits
		        Pattern pattern = Pattern.compile("\\d{3}-\\d{4}");

		        // Create a matcher to find matches in input strings
		        Matcher matcher = pattern.matcher("123-4567");

		        // Check if the input string matches the pattern
		        boolean isMatch = matcher.matches();

		        // Print the result
		        System.out.println("123-4567 matches pattern: " + isMatch);

		        // Create a pattern to match a string with one or more digits
		        Pattern pattern2 = Pattern.compile("\\d+");

		        // Create a matcher to find matches in input strings
		        Matcher matcher2 = pattern2.matcher("abc123def");

		        // Find the first occurrence of the pattern in the input string
		        if (matcher2.find()) {
		            // Print the matched string
		            System.out.println("Matched string: " + matcher2.group());
		        }
		    
	}

}
