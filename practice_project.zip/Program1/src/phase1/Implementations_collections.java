package phase1;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

public class Implementations_collections {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		        // Create an ArrayList of integers
		        ArrayList<Integer> numbers = new ArrayList<>();
		        numbers.add(1);
		        numbers.add(2);
		        numbers.add(3);

		        // Iterate through the ArrayList and print each number
		        System.out.println("Numbers in ArrayList:");
		        for (int number : numbers) {
		            System.out.println(number);
		        }

		        // Create a HashSet of strings
		        HashSet<String> names = new HashSet<>();
		        names.add("Debas");
		        names.add("Chandu");
		        names.add("Shiva");

		        // Iterate through the HashSet and print each name
		        System.out.println("\nNames in HashSet:");
		        for (String name : names) {
		            System.out.println(name);
		        }

		        // Create a HashMap of strings to integers
		        HashMap<String, Integer> scores = new HashMap<>();
		        scores.put("Debas", 95);
		        scores.put("Chandu", 80);
		        scores.put("Shiva", 75);

		        // Iterate through the HashMap and print each name and score
		        System.out.println("\nScores in HashMap:");
		        for (String name : scores.keySet()) {
		            int score = scores.get(name);
		            System.out.println(name + ": " + score);
		        }
		    
		

	}

}
