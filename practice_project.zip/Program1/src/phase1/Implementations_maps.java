package phase1;

import java.util.HashMap;
import java.util.Map;

public class Implementations_maps {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		        // Create a HashMap of strings to integers
		        Map<String, Integer> ages = new HashMap<>();
		        ages.put("Debas", 25);
		        ages.put("Chandu", 30);
		        ages.put("Shiva", 35);

		        // Print out the age of Debas
		        System.out.println("Debas's age is " + ages.get("Debas"));

		        // Check if the map contains the key "Chandu"
		        if (ages.containsKey("Chandu")) {
		            System.out.println("Chandu's age is " + ages.get("Chandu"));
		        } else {
		            System.out.println("Chandu's age is not in the map");
		        }

		        // Iterate through the map and print out each name and age
		        System.out.println("Names and ages in the map:");
		        for (Map.Entry<String, Integer> entry : ages.entrySet()) {
		            String name = entry.getKey();
		            int age = entry.getValue();
		            System.out.println(name + ": " + age);
		        }

		        // Remove Bob from the map
		        ages.remove("Siva");

		        // Print out the updated map
		        System.out.println("Updated map:");
		        for (Map.Entry<String, Integer> entry : ages.entrySet()) {
		            String name = entry.getKey();
		            int age = entry.getValue();
		            System.out.println(name + ": " + age);
		        }
		    
		

	}

}
