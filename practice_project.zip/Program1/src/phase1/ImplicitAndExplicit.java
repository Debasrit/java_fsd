package phase1;

public class ImplicitAndExplicit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			      int i = 10;
			      double d = 2.5;

			      // Implicit Type Casting
			      double result1 = i; // Automatically converts int to double
			      System.out.println("Implicit Type Casting: " + result1);

			      // Explicit Type Casting
			      int result2 = (int) d; // Manually converts double to int
			      System.out.println("Explicit Type Casting: " + result2);
			   
	}

}
