package phase1;

public class Outer {
    private int outerValue;

    public Outer(int value) {
        outerValue = value;
    }

    public void print() {
        System.out.println("Outer value: " + outerValue);
    }

    // Inner class
    public class Inner {
        private int innerValue;

        public Inner(int value) {
            innerValue = value;
        }

        public void print() {
            System.out.println("Inner value: " + innerValue);
        }

        public void printOuter() {
            System.out.println("Outer value from inner class: " + outerValue);
        }
    }

    public static void main(String[] args) {
        // Create an instance of the outer class
        Outer outer = new Outer(10);

        // Create an instance of the inner class
        Outer.Inner inner = outer.new Inner(20);

        // Call methods on the outer and inner objects
        outer.print();
        inner.print();
        inner.printOuter();
    }
}
