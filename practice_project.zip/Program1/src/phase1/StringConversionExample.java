package phase1;

public class StringConversionExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Create a string
        String str = "Hello, ";

        // Convert string to StringBuffer
        StringBuffer sb = new StringBuffer(str);

        // Convert string to StringBuilder
        StringBuilder sbuilder = new StringBuilder(str);

        // Display original string
        System.out.println("Original string: " + str);

        // Display StringBuffer
        System.out.println("StringBuffer: " + sb);

        // Display StringBuilder
        System.out.println("StringBuilder: " + sbuilder);
	}

}
