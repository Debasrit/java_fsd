package program3;

class linked {
    int data;
    linked prev;
    linked next;

    linked(int data) {
        this.data = data;
        this.prev = null;
        this.next = null;
    }
}

class DoublyLinkedList {
    linked head;

    void insert(int data) {
        linked newNode = new linked(data);

        if (head == null) {
            head = newNode;
        } else {
            linked temp = head;
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = newNode;
            newNode.prev = temp;
        }
    }

    void traverseForward() {
        if (head == null) {
            System.out.println("Doubly linked list is empty.");
            return;
        }

        linked temp = head;
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.next;
        }
        System.out.println();
    }

    void traverseBackward() {
        if (head == null) {
            System.out.println("Doubly linked list is empty.");
            return;
        }

        linked temp = head;
        while (temp.next != null) {
            temp = temp.next;
        }

        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.prev;
        }
        System.out.println();
    }
}

public class doubly_linked_list {
    public static void main(String[] args) {
        DoublyLinkedList doublyLinkedList = new DoublyLinkedList();

        // Insert elements into the doubly linked list
        doublyLinkedList.insert(10);
        doublyLinkedList.insert(20);
        doublyLinkedList.insert(30);
        doublyLinkedList.insert(40);
        doublyLinkedList.insert(50);

        // Traverse the doubly linked list in the forward direction
        System.out.println("Doubly Linked List (Forward):");
        doublyLinkedList.traverseForward();

        // Traverse the doubly linked list in the backward direction
        System.out.println("Doubly Linked List (Backward):");
        doublyLinkedList.traverseBackward();
    }
}
