package program3;


import java.util.LinkedList;
import java.util.Queue;

public class elements_in_queue {
    public static void main(String[] args) {
        Queue<Integer> queue = new LinkedList<>();

        // Insert elements into the queue
        queue.add(10);
        queue.add(20);
        queue.add(30);
        queue.add(40);
        queue.add(50);

        // Display the elements in the queue
        System.out.println("Queue elements: " + queue);

        // Remove the front element from the queue
        int removedElement = queue.remove();
        System.out.println("Removed element: " + removedElement);

        // Display the elements in the queue after removal
        System.out.println("Queue elements after removal: " + queue);

        // Access the front element without removing it
        int frontElement = queue.peek();
        System.out.println("Front element: " + frontElement);

        // Check if the queue is empty
        boolean isEmpty = queue.isEmpty();
        System.out.println("Is queue empty? " + isEmpty);
    }
}
