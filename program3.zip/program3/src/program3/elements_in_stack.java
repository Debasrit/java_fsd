package program3;

import java.util.Stack;

public class elements_in_stack {
    public static void main(String[] args) {
        Stack<Integer> stack = new Stack<>();

        // Insert elements into the stack
        stack.push(10);
        stack.push(20);
        stack.push(30);
        stack.push(40);
        stack.push(50);

        // Display the elements in the stack
        System.out.println("Stack elements: " + stack);

        // Remove the top element from the stack
        int removedElement = stack.pop();
        System.out.println("Removed element: " + removedElement);

        // Display the elements in the stack after removal
        System.out.println("Stack elements after removal: " + stack);

        // Access the top element without removing it
        int topElement = stack.peek();
        System.out.println("Top element: " + topElement);

        // Check if the stack is empty
        boolean isEmpty = stack.isEmpty();
        System.out.println("Is stack empty? " + isEmpty);
    }
}
