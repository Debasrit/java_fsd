package program3;
import java.util.Arrays;
public class four_smallest_element {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


        // Create an unsorted list
        int[] nums = { 9, 4, 7, 1, 5, 2, 8, 3, 6 };

        // Find the fourth smallest element
        int fourthSmallest = findFourthSmallest(nums);

        // Print the result
        System.out.println("Fourth Smallest Element: " + fourthSmallest);
    }

    public static int findFourthSmallest(int[] nums) {
        // Sort the array in ascending order
        Arrays.sort(nums);

        // Return the element at index 3 (0-based indexing)
        return nums[3];
    }
}
