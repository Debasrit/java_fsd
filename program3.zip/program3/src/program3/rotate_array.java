package program3;

public class rotate_array {

	public static void main(String[] args) {	

        // Create an array
        int[] arr = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };

        // Display the original array
        System.out.println("Original Array: ");
        displayArray(arr);

        // Perform right rotation by 5 steps
        int steps = 5;
        rightRotateArray(arr, steps);

        // Display the rotated array
        System.out.println("\nRotated Array: ");
        displayArray(arr);
    }

    public static void rightRotateArray(int[] arr, int steps) {
        int length = arr.length;

        // Adjust the number of steps if it exceeds the length of the array
        steps = steps % length;

        // Create a temporary array to store the rotated elements
        int[] temp = new int[length];

        // Copy the elements to the temporary array in the rotated order
        for (int i = 0; i < length; i++) {
            temp[(i + steps) % length] = arr[i];
        }

        // Copy the elements from the temporary array back to the original array
        for (int i = 0; i < length; i++) {
            arr[i] = temp[i];
        }
    }

    public static void displayArray(int[] arr) {
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " ");
        }
        System.out.println();
    }
}
