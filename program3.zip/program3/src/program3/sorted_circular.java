package program3;

class sorted {
    int data;
    sorted next;

    sorted(int data) {
        this.data = data;
        this.next = null;
    }
}

class CircularLinkedList {
    sorted head;

    void insert(int data) {
        sorted newNode = new sorted(data);

        if (head == null) {
            newNode.next = newNode;
            head = newNode;
        } else if (data <= head.data) {
            sorted temp = head;
            while (temp.next != head) {
                temp = temp.next;
            }
            temp.next = newNode;
            newNode.next = head;
            head = newNode;
        } else {
            sorted current = head;
            while (current.next != head && current.next.data < data) {
                current = current.next;
            }
            newNode.next = current.next;
            current.next = newNode;
        }
    }

    void display() {
        if (head == null) {
            System.out.println("Circular linked list is empty.");
            return;
        }

        sorted temp = head;
        do {
            System.out.print(temp.data + " ");
            temp = temp.next;
        } while (temp != head);
        System.out.println();
    }
}

public class sorted_circular {
    public static void main(String[] args) {
        CircularLinkedList circularLinkedList = new CircularLinkedList();

        // Insert elements into the circular linked list
        circularLinkedList.insert(10);
        circularLinkedList.insert(20);
        circularLinkedList.insert(30);
        circularLinkedList.insert(40);
        circularLinkedList.insert(50);

        // Display the circular linked list
        System.out.println("Circular Linked List:");
        circularLinkedList.display();
    }
}
