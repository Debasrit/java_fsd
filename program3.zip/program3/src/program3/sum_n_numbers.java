package program3;
import java.util.Scanner;
public class sum_n_numbers {

	public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        // Read the value of n
        System.out.print("Enter the value of n: ");
        int n = scanner.nextInt();

        // Create an array of size n
        int[] arr = new int[n];

        // Read the elements of the array
        System.out.println("Enter the elements of the array:");
        for (int i = 0; i < n; i++) {
            arr[i] = scanner.nextInt();
        }

        // Read the values of L and R
        System.out.print("Enter the value of L: ");
        int L = scanner.nextInt();

        System.out.print("Enter the value of R: ");
        int R = scanner.nextInt();

        // Calculate the sum of elements in the range of L and R
        int sum = 0;
        for (int i = L; i <= R; i++) {
            sum += arr[i];
        }

        // Print the sum
        System.out.println("Sum of elements in the range of L and R: " + sum);

        scanner.close();
    }
}
