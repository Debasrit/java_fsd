package phase2;

class CustomException extends Exception {
    public CustomException(String message) {
        super(message);
    }
}

public class Exception_java {
    public static void main(String[] args) {
        try {
            divide(10, 0);
        } catch (ArithmeticException e) {
            System.out.println("ArithmeticException occurred: " + e.getMessage());
        } catch (CustomException e) {
            System.out.println("CustomException occurred: " + e.getMessage());
        } finally {
            System.out.println("Finally block executed");
        }
    }

    public static void divide(int dividend, int divisor) throws CustomException {
        if (divisor == 0) {
            throw new ArithmeticException("Cannot divide by zero");
        } else if (divisor == 1) {
            throw new CustomException("Custom exception occurred");
        } else {
            int result = dividend / divisor;
            System.out.println("Result: " + result);
        }
    }
}
