package phase2;

public class try_catch 
{
    public static void main(String args[]) 
    {
int[] array = new int[3];
        try 
        {
array[7] = 3;
        }
        catch (ArrayIndexOutOfBoundsException e) 
        {
            System.out.println("Hi Debasrit how are you?"); 
        }
        finally 
        {
            System.out.println("The array is of size " + array.length);
        }
    }
}
